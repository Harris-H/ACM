#include<bits/stdc++.h>
using namespace std;
int Rand(int L, int R) {
        static mt19937 rnd(time(0));
        int res = (int)((1.0 * rnd() / UINT_MAX) * (R - L + 1)) + L;
        return res;
}
const int N=1e5+5;
int fa[N];
int find(int x){
	return x==fa[x]?x:fa[x]=find(fa[x]);
}
void fun(int n){
	for(int i=1;i<=n;i++)fa[i]=i;
	int cnt=0;
	while(cnt<n-1){
		int x=Rand(1,n),y=Rand(1,n);
		int x1=find(x),y1=find(y);
		if(x1!=y1) fa[x1]=y1,cnt++,printf("%d %d\n",x,y);
	}
}
int main(){
	string str;
	for(int kase=9;kase<=9;kase++){
	string str;
	str="./data/";
	str+=to_string(kase)+".in";	// ".data/i.in"
	freopen(str.c_str(),"w",stdout); 
	int n=Rand(1e5,1e5),q=Rand(1,1e5);
	printf("%d %d\n",n,q);
	for(int i=1;i<n;i++){
		printf("%d ",Rand(1,1e9));
	}
	printf("%d\n",Rand(1,1e9));
	fun(n);
	while(q--){
		int l1,r1,l2,r2;
		l1=Rand(1,n),r1=Rand(1,n),l2=Rand(1,n),r2=Rand(1,n);
		printf("%d %d %d %d\n",l1,r1,l2,r2);
	}
	} 
	return 0;
} 
