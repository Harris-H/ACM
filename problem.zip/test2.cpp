#include<bits/stdc++.h>
using namespace std;
int Rand(int L, int R) {
        static mt19937 rnd(time(0));
        int res = (int)((1.0 * rnd() / UINT_MAX) * (R - L + 1)) + L;
        return res;
}
int main(){
	string str;
	string ans; 
	map<int,string>mp;
	mp[0]="+",mp[1]="-",mp[2]="/",mp[3]="*";
	for(int i=1;i<10;i++){ 
	str="./data/";
	str+=to_string(i)+".in";	// ".data/i.in"
	freopen(str.c_str(),"w",stdout); 
		int cnt=Rand(7,10);
	 	printf("%d\n",cnt);
	 	map<int,int>mp;
	 	int f=0;
	 	for(int j=1;j<=cnt;j++){
	 		while(1){
	 			int x=Rand(1,cnt);
	 			if(!mp[x]){
	 				mp[x]=1;
	 				if(!f) printf("%d",x),f=1;
	 				else printf(" %d",x);
	 				break;
				 }
			 }
		 }
	  }
}
