#include<bits/stdc++.h>
using namespace std;
int Rand(int L, int R) {
        static mt19937 rnd(time(0));
        int res = (int)((1.0 * rnd() / UINT_MAX) * (R - L + 1)) + L;
        return res;
}
int main(){
	string str;
	string ans; 
	map<int,string>mp;
	mp[0]="+",mp[1]="-",mp[2]="/",mp[3]="*";
	for(int i=2;i<5;i++){ 
	str="./data/";
	str+=to_string(i)+".in";	// ".data/i.in"
	freopen(str.c_str(),"w",stdout); 
	  ans+=to_string(Rand(1,1e8));
	  for(int j=1;j<100;j++){
	  	 ans+=" "+ mp[j%2];
	  	 ans+=" "+ to_string(Rand(1,1e8)) ; 
	  }
	  cout<<ans;
	}
}
