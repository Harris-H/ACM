#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e3+5,M=2e4+5,inf=0x3f3f3f3f;
ll fac[N];
int n,a[N];
ll s[N];
void init(int n){
	fac[0]=1;for(int i=1;i<=n;i++) fac[i]=fac[i-1]*i,s[i]=0;
}
#define lowbit(x) x&(-x)
void upd(int x,int v){
	while(x<=n){
		s[x]+=v;x+=lowbit(x);
	}return;
}
ll que(int x){
	ll ans=0;
	while(x){
		ans+=s[x];x-=lowbit(x);
	}return ans;
}
int main(){
		scanf("%d",&n);
	init(n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	ll ans=1;
	for(int i=n;i;i--) ans=(ans+1LL*fac[n-i]*que(a[i]-1)),upd(a[i],1);
	printf("%lld\n",ans);
	return 0;
}
