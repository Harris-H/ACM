#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull; 
const int N=1e3+5,M=2e4+5,inf=0x3f3f3f3f,mod=1e9+7;
#define mst(a,b) memset(a,b,sizeof a)
#define PII pair<int,int>
#define fi first
#define se second
#define pb emplace_back
#define SZ(a) (int)a.size()
#define IOS ios::sync_with_stdio(false),cin.tie(0) 
void Print(int *a,int n){
	for(int i=1;i<n;i++)
		printf("%d ",a[i]);
	printf("%d\n",a[n]); 
}
struct node{
	int v;
	char c;
	bool f;
}u;
stack<node>s;
queue<node>q;
map<char,int>mp;
void fun(string &a){
	mp['+']=mp['-']=1;
	mp['*']=mp['/']=2;
	int n=SZ(a);
	for(int i=0;i<n;i++){
		if(a[i]==' ')continue;
		if(a[i]=='('){
			u.f=1,u.c='(';
			s.push(u);
		}
		else if(a[i]==')'){
			while(!s.empty()&&s.top().c!='(') q.push(s.top()),s.pop();
			s.pop();	
		}
		else if(isdigit(a[i])){
			u.f=0;
			u.v=a[i++]-'0';
			while(i<n&&isdigit(a[i]))
				u.v=u.v*10+a[i++]-'0';
			i--;
			q.push(u);
		}
		else {
			u.f=1;
			u.c=a[i];
			while(!s.empty()&&mp[s.top().c]>=mp[u.c])
				q.push(s.top()),s.pop();
			s.push(u);
		}
	}
	while(!s.empty()) q.push(s.top()),s.pop();
}
int cal(){
	stack<int>st;
	int _=0;
	while(!q.empty()){
		u=q.front();q.pop();
	if(!_){
		if(u.f) printf("%c",u.c);
		else printf("%d",u.v);
		_=1;
	}
	else {
		if(u.f) printf(" %c",u.c);
		else printf(" %d",u.v);
	}
		if(u.f) {
			int y=st.top();st.pop();
			int x=st.top();st.pop();
			if(u.c=='+') st.push(x+y);
			else if(u.c=='-') st.push(x-y);
			else if(u.c=='*') st.push(x*y);
			else if(u.c=='/') st.push(x/y);			
		}
		else st.push(u.v);
	}
	printf("\n");
	return st.top();
}
int main(){
	string a;
	getline(cin,a);
	fun(a);
	printf("%d\n",cal());
	return 0;
}

