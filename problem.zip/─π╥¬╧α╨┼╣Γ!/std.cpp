#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull; 
const int N=1e5+5,M=2e4+5,inf=0x3f3f3f3f,mod=1e9+7;
#define mst(a,b) memset(a,b,sizeof a)
#define PII pair<int,int>
#define fi first
#define se second
#define pb emplace_back
#define SZ(a) (int)a.size()
#define IOS ios::sync_with_stdio(false),cin.tie(0) 
void Print(int *a,int n){
	for(int i=1;i<n;i++)
		printf("%d ",a[i]);
	printf("%d\n",a[n]); 
}
#define lx x<<1
#define rx x<<1|1
#define len(x) (a[x].r-a[x].l+1)
struct node{
	int l,r;
	ll lz;
	ll s;
}a[N<<2];
int w[N],val[N];
inline void re(int x){
	a[x].s=a[lx].s+a[rx].s;
}
inline void pushdown(int x){
	if(a[x].lz){
		a[lx].lz+=a[x].lz,a[rx].lz+=a[x].lz;
		a[lx].s+=len(lx)*a[x].lz;
		a[rx].s+=len(rx)*a[x].lz;
		a[x].lz=0;
	}
}
void build(int x,int l,int r){
	a[x].l=l,a[x].r=r;
	if(l==r){
		a[x].s=w[l];
		return;
	}
	int mid=(l+r)>>1;
	build(lx,l,mid);
	build(rx,mid+1,r);
	re(x);
}
void upd(int x,int l,int r,int val){
	if(a[x].l>=l&&a[x].r<=r){
		a[x].s+=1LL*len(x)*val;
		a[x].lz+=val;return;
	}
	pushdown(x);
	int mid=(a[x].l+a[x].r)>>1;
	if(l<=mid) upd(lx,l,r,val);
	if(r>mid) upd(rx,l,r,val);
	re(x);
}
ll que(int x,int l,int r){
	if(a[x].l>=l&&a[x].r<=r) return a[x].s;
	int mid=(a[x].l+a[x].r)>>1;
	pushdown(x);
	ll ans=0;
	if(l<=mid) ans+=que(lx,l,r);
	if(r>mid) ans+=que(rx,l,r);
	return ans;
}
struct edge{
	int to,nt;
}e[N<<1];
int h[N],cnt;
void add(int u,int v){
	e[++cnt]={v,h[u]},h[u]=cnt;
	e[++cnt]={u,h[v]},h[v]=cnt;
}
int sz[N],fa[N],son[N],top[N],dfn[N],dep[N];
void dfs(int u,int f){
	sz[u]=1,fa[u]=f,dep[u]=dep[f]+1;
	for(int i=h[u];i;i=e[i].nt){
		int v=e[i].to;
		if(v==f) continue;
		dfs(v,u);
		sz[u]+=sz[v];
		if(sz[son[u]]<sz[v]) son[u]=v;
	}
}
int id;
void dfs1(int u,int tp){
	top[u]=tp,dfn[u]=++id;w[id]=val[u];
	if(son[u]) dfs1(son[u],tp);
	for(int i=h[u];i;i=e[i].nt){
		int v=e[i].to;
		if(v!=fa[u]&&v!=son[u]) dfs1(v,v);
	}
}
void upd_c(int x,int y,int z){	//chain update
	 while(top[x]!=top[y]){
	 	if(dep[top[x]]<dep[top[y]]) swap(x,y);
	 	upd(1,dfn[top[x]],dfn[x],z);
	 	x=fa[top[x]];
	 }
	 if(dep[x]<dep[y]) swap(x,y);
	 upd(1,dfn[y],dfn[x],z);
}
ll que_c(int x,int y){		//chain query
	ll ans=0;
	while(top[x]!=top[y]){
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
	 	ans=(ans+que(1,dfn[top[x]],dfn[x]));
	 	x=fa[top[x]];
	 }
	 if(dep[x]<dep[y]) swap(x,y);
	 ans=(ans+que(1,dfn[y],dfn[x]));
	 return ans;
}
struct Mat{
	ll a[3][3];
	Mat operator *(const Mat &m)const{
		Mat b;mst(b.a,0);
		for(int i=1;i<=2;i++)	
			for(int j=1;j<=2;j++)
				for(int k=1;k<=2;k++)
				b.a[i][j]=(b.a[i][j]+a[i][k]*m.a[k][j]%mod)%mod;
		return b;
	}
};
Mat ksm(Mat a,int n){
	Mat s;
	s.a[1][1]=s.a[1][2]=1;
	while(n){
		if(n&1) s=s*a;
		a=a*a;
		n>>=1;
	}
	return s;
}
ll herio(ll x,ll y){
	x=__gcd(x,y);
	if(x<=2) return 1;
	else {
		Mat b;
		b.a[2][2]=0;
		b.a[1][1]=b.a[1][2]=b.a[2][1]=1;
		b=ksm(b,x-2);
		return b.a[1][1];
	}
}
void solve(){
	
	int n,q;
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++) scanf("%d",&val[i]);
	for(int i=1;i<n;i++){
		int u,v;scanf("%d%d",&u,&v);
		add(u,v);
	}
	dfs(1,0),dfs1(1,1);build(1,1,n);
	while(q--){
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ll x=que_c(l1,r1);
		ll y=que_c(l2,r2);
		//printf("x=%lld y=%lld\n",x,y);
		printf("%lld\n",herio(x,y));
	}
}
int main(){
	//freopen("./data/secret/9.in","r",stdin);
	//freopen("./data/secret/9.ans","w",stdout);
	solve();
	return 0;
}

