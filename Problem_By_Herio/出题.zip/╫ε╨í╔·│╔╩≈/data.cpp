#include<bits/stdc++.h>
using namespace std;
int Rand(int L, int R) {
        static mt19937 rnd(time(0));
        int res = (int)((1.0 * rnd() / UINT_MAX) * (R - L + 1)) + L;
        return res;
}
int main(){
	for(int kase=10;kase<=10;kase++){ 
		string str="./data/"+to_string(kase)+".in";
		freopen(str.c_str(),"w",stdout);
		//cout<<str<<"\n";
		int n=Rand(1000,1000),k=Rand(300,n);
		printf("%d %d\n",n,k);
		for(int i=1;i<=n;i++){
			int x=Rand(0,1e4),y=Rand(0,1e4);
			printf("%d %d\n",x,y); 
		} 
	}
	return 0;
} 
