#include<stdio.h>
//using namespace std;
//typedef long long ll;
//typedef pair<int, int> P;
//const int INF=0x3f3f3f3f;
const int MAX_N=1e3+10;
//const int MOD = 1e9 + 7;
int N, M, T, A, S, V;
int a[MAX_N];
void solve(){
    scanf("%d", &N);
    for(int i = 0; i < N; i++ ){
        scanf("%d", &a[i]);
    }
    int res = 0, t;
    for(int i = 0; i < N; i++){
        for(int j = i+1; j < N; j++){
            for(int k = 0; k < N; k++){
                if(k != i && k != j){
                    t = (a[i] + a[j]) ^ a[k];
                    if(t > res){
                        res = t ;
                    }
                }
            }
        }
    }
    printf("%d\n", res);
}
int main(){
	freopen("./data/12.in","r",stdin);
    int TCASE = 1;
//    scanf("%d", &TCASE);
    while(TCASE--){
        solve();
    }
    return 0;
}
