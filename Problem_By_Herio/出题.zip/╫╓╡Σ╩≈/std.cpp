#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1505,M=3e4+5,inf=0x3f3f3f3f,mod=1e9+7;
#define mst(a) memset(a,0,sizeof a)
struct Trie{
	int son[M][2],sz[M],cnt,val[M];
	void init(){cnt=0,mst(son[0]);} 
	void ins(int x){	//����. 
	int p=0;
	for(int i=30;~i;i--){
		int &s=son[p][x>>i&1];
		if(!s) s=++cnt,mst(son[cnt]),sz[cnt]=val[cnt]=0;
		p=s,sz[p]++;
	}
	val[p]=x;
	}
	void del(int x){	//ɾ��. 
		int p=0;
		for(int i=30;~i;i--){
			int s=x>>i&1;
			p=son[p][s];
			--sz[p];
		}
	}
	int que(int x){		//��ѯ. 
		int p=0;
	for(int i=30;~i;i--){
		int s=x>>i&1;
		if(son[p][!s]&&sz[son[p][!s]]) p=son[p][!s];
		else p=son[p][s];
	} 
	return x^val[p]; 
	}
}T;
int t,n,a[N],ans;
int main(){
	freopen("./data/12.in","r",stdin); 
		scanf("%d",&n);T.init();ans=0;//��ʼ�� 
		for(int i=1;i<=n;i++) scanf("%d",&a[i]),T.ins(a[i]);
		for(int i=1;i<n;i++){	//��ɾ��,��ѯ�ٲ���. 
			T.del(a[i]);
			for(int j=i+1;j<=n;j++){
				T.del(a[j]);
				ans=max(ans,T.que(a[i]+a[j]));
				T.ins(a[j]);
			}
			T.ins(a[i]);
		}
		printf("%d\n",ans);
	return 0;
}

