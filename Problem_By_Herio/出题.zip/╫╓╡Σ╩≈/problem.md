# Description

Herio想不出故事了。

给定数组$a$有$n$个数，求$\max\limits_{i,j,k}(a_i+a_j)\oplus a_k$，$i,j,k$各不相同。

# Input

输入的第一行是一个整数$n$，表示数组的大小。

下一行$n$个数表示$a_i$ 。

# Output

输出一行一个整数，表示答案。

# Sample Input

```
3
1 2 3
```

# Sample Output

```
6
```

# Hint

$3\le n\le 1000\\ 0\le a_i\le 10^9$

