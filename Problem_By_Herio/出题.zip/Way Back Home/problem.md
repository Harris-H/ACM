# Description

Herio写了一首英文诗：

I come into a dream
Leaves fall down but spring
over a lake birds flying
village have its nice moring
everywhere can feel happiness
Years have never been
owners don't need anything
until the sun bring another wind

# Input

无

# Output

输出一共八行。

每行一个整数，表示这首诗该行第一个字母在整首诗中出现的次数(大小写不敏感)

