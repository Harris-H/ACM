#include<bits/stdc++.h>
using namespace std;
int c[26];
char ch[]="iloveyou";
int ans[]={14,9,8,7,27,4,8,3};
int main(){
	/*
		string a;
	int k=0;
	while(getline(cin,a)){
		for(auto x:a)
			if(isalpha(x)) c[tolower(x)-'a']++;
		k++;
		if(k==15) break; 
	} 
	for(int i=0;i<8;i++) printf("%d\n",c[ch[i]-'a']);
	*/
	for(int i=0;i<8;i++) printf("%d\n",ans[i]);
	return 0;
}
